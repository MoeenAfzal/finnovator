import React from "react";
import styles from "./styles.module.css";
import F from "../../components/F";
import Company from "../../components/Company";
import Clients from "../../components/Client";
import Industries from "../../components/Industries";
import OptFor from "../../components/OptFor";

export default function index() {
  return (
    <div className={styles.Home}>
      <F />
      <Company />
      <Industries />
      <Clients />
      <OptFor />
    </div>
  );
}

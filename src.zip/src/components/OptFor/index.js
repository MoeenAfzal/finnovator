import React, { useEffect, useRef } from "react";
import styles from "./styles.module.css";
import image1 from "../../assets/images/aaaaaaaaaaaa-1.webp";

export default function Index() {
  const headingRef = useRef(null);
  const paraRefs = useRef([]);

  useEffect(() => {
    let lastScrollTop = 0;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const currentScrollTop =
            window.pageYOffset || document.documentElement.scrollTop;
          if (currentScrollTop > lastScrollTop) {
            // Scrolling down
            if (entry.isIntersecting) {
              entry.target.classList.add(styles.slideUp);
              entry.target.classList.remove(styles.hidden);
            }
          } else {
            // Scrolling up
            if (!entry.isIntersecting) {
              entry.target.classList.remove(styles.slideUp);
              entry.target.classList.add(styles.hidden);
            }
          }
          lastScrollTop = currentScrollTop <= 0 ? 0 : currentScrollTop;
        });
      },
      { threshold: 0.1 }
    );

    observer.observe(headingRef.current);

    paraRefs.current.forEach((paraRef) => {
      observer.observe(paraRef);
    });

    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <div className={`${styles.Company}`}>
      <div className={`${styles.company_flex}`}>
        <div className={`${styles.content}`}>
          <h2 className={`sameH ${styles.hidden}`} ref={headingRef}>
            Web Design Company in Saudi - Why Opt for Element8?
          </h2>
          <p
            className={`sameP ${styles.hidden}`}
            ref={(ref) => (paraRefs.current[0] = ref)}
          >
            At Element8, we understand the evolving digital landscape and
            leverage the latest technologies to ensure your website stands out.
            Our expert website design team combines creativity and technical
            prowess to deliver bespoke web solutions that resonate with your
            brand. From sleek and responsive interfaces to robust backend
            systems, we tailor our web design services to meet your unique
            requirements.
          </p>
          <p
            className={`sameP ${styles.hidden}`}
            ref={(ref) => (paraRefs.current[1] = ref)}
          >
            We prioritize user-centric website design, security, and optimal
            functionality, guaranteeing a competitive edge in today’s digital
            landscape. Elevate your brand with our commitment to excellence in
            web design and development, solidifying Element8 as your trusted
            partner for online success in Saudi Arabia.
          </p>
        </div>
        <div
          className={`${styles.image} ${styles.hidden}`}
          ref={(ref) => (paraRefs.current[2] = ref)}
        >
          <img src={image1} alt="web-design" />
        </div>
      </div>
    </div>
  );
}

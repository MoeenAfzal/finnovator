import React, { useEffect, useRef } from "react";
import listimage from "../../assets/images/list-icn-n.svg";
import listbackground from "../../assets/images/element-cer-02.svg";
import styles from "./styles.module.css";

export default function Index() {
  const titleRef = useRef(null);
  const cardRefs = useRef([]);

  const industries = [
    {
      title: "Real Estate",
      description:
        "Showcase properties elegantly with our real estate-focused web design and development services.",
    },
    {
      title: "Healthcare",
      description:
        "Deliver a seamless online experience with our healthcare-focused web solutions.",
    },
    {
      title: "Retail & Ecommerce",
      description:
        "Drive sales and engagement with our custom-built, user-friendly ecommerce websites.",
    },
    {
      title: "Education",
      description:
        "Transform learning experiences with our innovative web solutions tailored for the education sector.",
    },
    {
      title: "Industrial",
      description:
        "Streamline operations with our web solutions designed for the efficiency-driven industrial sector.",
    },
    {
      title: "FMCG",
      description:
        "Boost consumer engagement with our web design services tailored for the fast-moving consumer goods industry.",
    },
  ];

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add(styles.slideUp);
            entry.target.classList.remove(styles.hidden);
          } else {
            entry.target.classList.remove(styles.slideUp);
            entry.target.classList.add(styles.hidden);
          }
        });
      },
      { threshold: 0.1 }
    );

    observer.observe(titleRef.current);

    cardRefs.current.forEach((cardRef) => {
      observer.observe(cardRef);
    });

    return () => {
      observer.disconnect();
    };
  }, []);

  return (
    <div className={`${styles.container}`}>
      <div />
      <div className={`${styles.content}`}>
        <div className={`${styles.heading}`} ref={titleRef}>
          <h3 className={`${styles.title} sameH`}>Industries We Cater</h3>
        </div>
        <div className={`${styles.grid}`}>
          {industries.map((industry, index) => (
            <div
              key={index}
              className={`${styles.card}`}
              ref={(ref) => (cardRefs.current[index] = ref)}
            >
              {index === 0 && (
                <img
                  src={listbackground}
                  alt=""
                  className={`${styles.backgroundImage}`}
                />
              )}
              <div className={`${styles.cardContent}`}>
                <img src={listimage} alt="" className={`${styles.icon}`} />
                <div>
                  <h3 className={`${styles.cardTitle}`}>{industry.title}</h3>
                  <p className={`${styles.description}`}>
                    {industry.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className={`${styles.button}`}>
          <button className={`${styles.contactButton} sameB`}>
            Contact Us
          </button>
        </div>
      </div>
    </div>
  );
}

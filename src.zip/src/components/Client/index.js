import React, { useEffect, useRef } from "react";
import styles from "./styles.module.css";
import listbackground from "../../assets/images/element-cer-02.svg";
import clientbackground from "../../assets/images/clients_bg.png";
import hisenseLogo from "../../assets/images/hisense-150x150.png";
import cmuqLogo from "../../assets/images/CMUQ-150x150.jpg";
import bankmusqatLogo from "../../assets/images/Bank-Muscat-150x150.jpg";
import iqgroupLogo from "../../assets/images/IQ-Group-150x150.jpg";
import saudibinladinLogo from "../../assets/images/saudi-binladen-group-150x150.png";
import riseLogo from "../../assets/images/Rise-150x150.jpg";
import depaLogo from "../../assets/images/Depa-1-150x150.jpg";
import ritadLogo from "../../assets/images/ritad_cables-150x150.png";
import dulscoLogo from "../../assets/images/dulsco-150x150.png";
import centralparkDIFCLogo from "../../assets/images/Central-Park-Towers-150x150.jpg";
import saudicastLogo from "../../assets/images/saudicast-150x150.png";
import tamLogo from "../../assets/images/tam-150x150.png";
import garminLogo from "../../assets/images/garmin-150x150.png";
import greenRiyadhLogo from "../../assets/images/green-Riyadh-150x150.png";
import alHilalBankLogo from "../../assets/images/al-Hilal-Bank-150x150.png";
import americanGardenLogo from "../../assets/images/american-Garden-150x150.png";
import tatweerLogo from "../../assets/images/Tatweer.jpg";
import unifiedLogo from "../../assets/images/Unified.jpg";

const clientsWithImages = [
  { name: "Hisense", image: hisenseLogo },
  { name: "Carnegie Mellon University Qatar", image: cmuqLogo },
  { name: "Bank Muscat", image: bankmusqatLogo },
  { name: "IQ Group", image: iqgroupLogo },
  { name: "Saudi Binladin Group", image: saudibinladinLogo },
  { name: "Rise", image: riseLogo },
  { name: "Depa", image: depaLogo },
  { name: "Ritad", image: ritadLogo },
  { name: "Dulsco", image: dulscoLogo },
  { name: "Central Park DIFC", image: centralparkDIFCLogo },
  { name: "Saudicast", image: saudicastLogo },
  { name: "TAM", image: tamLogo },
  { name: "Garmin", image: garminLogo },
  { name: "Green Riyadh", image: greenRiyadhLogo },
  { name: "Al Hilal Bank", image: alHilalBankLogo },
  { name: "American Garden", image: americanGardenLogo },
  { name: "Tatweer", image: tatweerLogo },
  { name: "Unified", image: unifiedLogo },
];

const Index = () => {
  const cardRefs = useRef([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, index) => {
          if (entry.isIntersecting) {
            entry.target.classList.add(styles.slideUp);
            entry.target.classList.remove(styles.hidden);
          }
        });
      },
      { threshold: 0.1 }
    );

    cardRefs.current.forEach((cardRef) => {
      observer.observe(cardRef);
    });

    return () => {
      cardRefs.current.forEach((cardRef) => {
        observer.unobserve(cardRef);
      });
    };
  }, []);

  return (
    <section className={`${styles.sec}`}>
      <div className={styles["clients-container"]}>
        <div>
          <h3 className={`${styles.clients_heading} sameH`}>Our Clients</h3>
        </div>
        <div className={styles["clients-grid"]}>
          <img
            src={clientbackground}
            alt=""
            className={`${styles.backgroundImageleft}`}
          />
          <img
            src={listbackground}
            alt=""
            className={`${styles.backgroundImageright}`}
          />
          {clientsWithImages.map((client, index) => (
            <div
              key={index}
              className={`${styles["client-item"]} ${styles.hidden}`}
              ref={(ref) => (cardRefs.current[index] = ref)}
            >
              <img
                src={client.image}
                alt={client.name}
                className={styles["client-image"]}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Index;

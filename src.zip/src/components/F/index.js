import React from "react";
import styles from "./styles.module.css";
export default function index() {
  return (
    <div className={`${styles.F}`}>
      <h1>Coming Soon F Animation</h1>
    </div>
  );
}

import React, { useEffect, useRef } from "react";
import styles from "./styles.module.css";
import image1 from "../../assets/images/web-design-img-01.webp";
import image2 from "../../assets/images/element-cer-01.svg";

export default function Index() {
  const headingRef = useRef(null);
  const imageRef = useRef(null);
  const paraRef = useRef(null);
  const buttonRef = useRef(null);

  useEffect(() => {
    let lastScrollTop = 0;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const currentScrollTop =
            window.pageYOffset || document.documentElement.scrollTop;
          if (currentScrollTop > lastScrollTop) {
            // Scrolling down
            if (entry.isIntersecting) {
              entry.target.classList.add(styles.slideUp);
              entry.target.classList.remove(styles.hidden);
              if (entry.target === headingRef.current && imageRef.current) {
                imageRef.current.classList.add(styles.slideUp);
                imageRef.current.classList.remove(styles.hidden);
              }
            }
          } else {
            // Scrolling up
            if (!entry.isIntersecting) {
              entry.target.classList.remove(styles.slideUp);
              entry.target.classList.add(styles.hidden);
              if (entry.target === headingRef.current && imageRef.current) {
                imageRef.current.classList.remove(styles.slideUp);
                imageRef.current.classList.add(styles.hidden);
              }
            }
          }
          lastScrollTop = currentScrollTop <= 0 ? 0 : currentScrollTop;
        });
      },
      { threshold: 0.1 }
    );

    const elements = [headingRef.current, paraRef.current, buttonRef.current];

    elements.forEach((element) => {
      if (element) observer.observe(element);
    });

    return () => {
      elements.forEach((element) => {
        if (element) observer.unobserve(element);
      });
    };
  }, []);

  return (
    <div className={styles.Company}>
      <div className={styles.Company_ring}>
        <img src={image2} alt="" />
      </div>
      <div className={styles.company_flex}>
        <div className={styles.content}>
          <h1 className={`sameH ${styles.hidden}`} ref={headingRef}>
            Website Design Company in Saudi Arabia
          </h1>
          <p className={`sameP ${styles.hidden}`} ref={paraRef}>
            Discover top-notch web design services in Saudi Arabia. Our expert
            team crafts dynamic websites using cutting-edge technologies like
            Python, PHP, ASP.net, and HTML5. Elevate your online presence with
            fully animated sites seamlessly integrated with APIs. Trust us to
            build a digital masterpiece tailored to your unique needs.
          </p>
          <button className={`sameB ${styles.hidden}`} ref={buttonRef}>
            Contact Us
          </button>
        </div>
        <div className={`${styles.hidden}`} ref={imageRef}>
          <img src={image1} alt="web-design" />
        </div>
      </div>
    </div>
  );
}
